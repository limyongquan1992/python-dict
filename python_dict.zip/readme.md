command to run:
python3 <python_script> <dictionary_file> <content_to_analyse_file>
eg: python3 dict1.py dict.txt text.txt
eg: python3 dict1.py dict.txt amazon_cells_labelled.txt

after run, see results at:
full logs of results: log.txt
dataset for ML: out.txt

feel free to modify dict.txt and text.txt for testing
report any bugs to me.
eg: like when content include some special character (), the analysis is incorrect.